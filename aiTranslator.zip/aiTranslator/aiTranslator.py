import sys

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtWidgets import QApplication, QWidget
from function.aiTranslator.aiTranslatorUi_rc import Ui_MainWin  # 导入生成的界面类
from function.aiTranslator.doubaoTranslation import DouBaoAI
from PyQt5.QtCore import QThread, pyqtSignal


class translatorThread(QThread):
    # 定义一个信号，当任务完成时发送消息给主线程
    translatorFinished = pyqtSignal(str, str)  # 第一个str为翻译框上语种标签的内容,第二个str为内容

    def __init__(self, language, content):
        super().__init__()
        self.language = language
        self.content = content
        # 初始化豆包ai翻译
        self.aiTranslator = DouBaoAI()

    def run(self) -> None:
        # 调用语种判断方法,判断当前内容的语种
        self.aiTranslator.languageDetermination(self.content)
        print(f"当前语种为{self.aiTranslator.languageDetermination_dict['language']}")
        # 判断当前内容语种与目标语种是否相同
        if self.aiTranslator.languageDetermination_dict['language'] == self.language:
            # 如果相同则self.language改为中文或者英语
            if self.language == "中文":
                self.language = "英语"
            else:
                self.language = "中文"
        print(f"翻译为{self.language}")
        self.aiTranslator.chat(language=self.language, content=self.content)
        print(self.aiTranslator.translation_dict['translation'])
        self.translatorFinished.emit(self.aiTranslator.translation_dict['translation'], self.language)


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        print("aiTranslator的MainWindow类初始化方法1")
        # 创建界面类的实例
        self.ui = Ui_MainWin()
        # 设置界面到主窗口
        self.ui.setupUi(self)
        # 设置QWidget的无边框和子窗口属性和置顶
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.SubWindow | Qt.WindowStaysOnTopHint)
        # 设置QWidget的透明属性
        self.setAttribute(Qt.WA_TranslucentBackground)

        # 记录鼠标按下时是否处在可拖动窗口的位置
        self.dragging = False
        # 记录鼠标相对于窗口左上角的偏移量
        self.offset = None

        # 控件初始化
        self.initControl()
        # 用来保存线程对象
        self.thread = None
        print("aiTranslator的MainWindow类初始化方法2")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            if event.x() < self.geometry().width() and event.y() < self.geometry().height():
                # 判断鼠标按下的位置是否在被允许拖动窗口的范围内
                self.dragging = True
            # 记录鼠标按下时相对于窗口左上角的偏移量
            self.offset = event.pos()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.LeftButton and self.dragging:
            # 计算窗口新的位置
            new_pos = self.pos() + event.pos() - self.offset
            self.move(new_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragging = False

    def initControl(self):
        self.ui.pushButtonClose.clicked.connect(self.hide)

        # 创建定时器
        self.timer = QTimer(self)
        # 设置为单次触发模式
        self.timer.setSingleShot(True)
        # 将定时器信号与修改翻译框内容的方法关联
        self.timer.timeout.connect(self.performTranslator)
        # 将文本输入框通过改变输入框文本的信号与开启定时器的函数关联
        self.ui.plainTextEdit.textChanged.connect(self.start_timer)

        # 当语言框改变时也触发函数
        self.ui.comboBox_2.currentIndexChanged.connect(self.start_timer)
        # 绑定清除按钮
        self.ui.pushButton.clicked.connect(self.ui.plainTextEdit.clear)
        # 绑定复制到剪切板按钮
        self.ui.pushButton_3.clicked.connect(self.copy_all_text_to_clipboard)
        self.ui.pushButton_3.clicked.connect(self.ui.plainTextEdit_2.copy)

    def start_timer(self):
        self.timer.start(600)  # 延迟 500 毫秒

    def performTranslator(self):
        # 获取要翻译的内容
        text = self.ui.plainTextEdit.toPlainText()
        language = self.ui.comboBox_2.currentText()
        self.thread = translatorThread(language=language, content=text)
        self.thread.translatorFinished.connect(lambda result, languageDetermination: (
            self.ui.comboBox_2.setCurrentText(languageDetermination), self.ui.plainTextEdit_2.setPlainText(result)))
        self.thread.start()
        # 在翻译框增加等待符号
        self.ui.plainTextEdit_2.appendPlainText("...")

    def copy_all_text_to_clipboard(self):
        # 获取 QPlainTextEdit 中的文本
        text = self.ui.plainTextEdit_2.toPlainText()
        # 获取系统剪贴板对象
        clipboard = QApplication.clipboard()
        # 将文本设置到剪贴板
        clipboard.setText(text)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # 创建主窗口实例
    window = MainWindow()
    # 显示主窗口
    window.show()
    # 进入应用程序的主循环
    sys.exit(app.exec_())
