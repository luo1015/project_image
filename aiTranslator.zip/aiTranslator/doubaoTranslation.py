import json
from openai import OpenAI


class DouBaoAI:
    def __init__(self):
        try:
            # 尝试打开并读取 translatorConfig.json 文件
            with open(r"translatorConfig\translator.json", 'r', encoding='utf-8') as f:
                # 使用 json.load 直接从文件对象中读取并解析 JSON 数据
                self.config = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # 处理文件不存在,或者格式错误的情况
            print("翻译器配置文件不存在,或者内容格式异常")
            return

        try:
            # self.config["role_path"]代表的路径文件为角色的设定文本文件
            with open(self.config["role_path"], 'r', encoding='utf-8') as f:
                # 存储角色设定文本
                self.roleSetText = f.read()
        except FileNotFoundError:
            # 处理文件不存在,或者格式错误的情况
            print("翻译器格式设定文本文件不存在")
            return

        # 获取apiKey和modelId
        self.apiKey = self.config["api_key"]
        self.modelId = self.config["model"]
        self.roleName = self.config["role_name"]

        # 用于承载OpenAi的对象
        self.configDouBao = None
        # 初始化OpenAi对象的配置
        self.initDouBao()

        # 用于存储聊天内容
        self.messages = [{"role": "system", "content": self.roleSetText}]
        # 用于存储翻译方法得到的json格式转换为的python字典
        self.translation_dict = None
        # 用于存储判断语言方法得到的json格式转换为的python字典
        self.languageDetermination_dict = None

        # ai设置方面
        self.stream = self.config["set"]["stream"]  # 是否流式响应

        self.max_tokens = self.config["set"]["max_tokens"]  # 模型回复的最大长度,各个模型取值不同,默认为4096

        self.stop = self.config["set"]["stop"]  # 模型遇到 stop 字段所指定的字符串时将停止继续生成，这个词语本身不会输出。最多支持 4 个
        # 字符串。["你好","天气"]

        self.frequency_penalty = self.config["set"]["frequency_penalty"]  # 频率惩罚系数。如果值为正，会根据新 token 在文本中的出
        # 现频率对其进行惩罚，从而降低模型逐字重复的可能性。取值范围为 [-2.0, 2.0]。

        self.presence_penalty = self.config["set"]["presence_penalty"]  # 存在惩罚系数。如果值为正，会根据新 token 到目前为止是否
        # 出现在文本中对其进行惩罚，从而增加模型谈论新主题的可能性。取值范围为 [-2.0, 2.0]。

        self.temperature = self.config["set"]["temperature"]  # 采样温度。控制了生成文本时对每个候选词的概率分布进行平滑的程度。取值范
        # 围为 [0, 1]。当取值为 0 时模型仅考虑对数概率最大的一个 token。较高的值（如 0.8）会使输出更加随机，而较低的值（如 0.2）会使输出更加集
        # 中确定。通常建议仅调整temperature 或 top_p 其中之一，不建议两者都修改。

        self.top_p = self.config["set"]["top_p"]  # 核采样概率阈值。模型会考虑概率质量在 top_p 内的 token 结果。取值范围为 [0, 1]。
        # 当取值为 0 时模型仅考虑对数概率最大的一个 token。如 0.1 意味着只考虑概率质量最高的前 10% 的 token，取值越大生成的随机性越高，取值越
        # 低生成的确定性越高。通常建议仅调整 temperature 或 top_p 其中之一，不建议两者都修改。

        self.logprobs = self.config["set"]["logprobs"]  # 是否返回输出 tokens 的对数概率。false：不返回对数概率信息true：返回消息
        # 内容中每个输出 token 的对数概率

        self.top_logprobs = self.config["set"]["top_logprobs"]  # 指定每个输出 token 位置最有可能返回的 token 数量，每个 token
        # 都有关联的对数概率。仅当 logprobs: true时可以设置 top_logprobs 参数，取值范围为 [0, 20]。

        self.logit_bias = self.config["set"]["logit_bias"]  # 调整指定 token 在模型输出内容中出现的概率，使模型生成的内容更加符合特
        # 定的偏好。logit_bias 字段接受一个 map 值，其中每个键为词表中的 token ID（使用 tokenization 接口获取），每个值为该 token 的偏
        # 差值，取值范围为 [-100, 100]。-1 会减少选择的可能性，1 会增加选择的可能性；-100 会完全禁止选择该 token，100 会导致仅可选择该 token
        # 。该参数的实际效果可能因模型而异。

    def initDouBao(self):
        # 初始化OpenAi对象的配置
        self.configDouBao = OpenAI(
            # 从环境变量中读取您的方舟API Key
            api_key=self.apiKey,
            base_url="https://ark.cn-beijing.volces.com/api/v3",
        )

    def chat(self, language, content):
        # content为用户要发送的聊天内容
        self.messages.append({"role": "user", "content": "请翻译为" + language + ": " + content})
        try:
            completion = self.configDouBao.chat.completions.create(
                model=self.modelId,
                messages=self.messages,
                # 是否流式响应
                stream=self.stream,
                max_tokens=self.max_tokens,
                stop=self.stop,
                frequency_penalty=self.frequency_penalty,
                presence_penalty=self.presence_penalty,
                temperature=self.temperature,
                top_p=self.top_p,
                logprobs=self.logprobs,
                top_logprobs=self.top_logprobs,
                logit_bias=self.logit_bias
            )
            # 非流式响应的聊天响应
            # 将 得到的回答的JSON 字符串转换为 Python 字典
            self.translation_dict = json.loads(completion.choices[0].message.content)
        except Exception as e:
            print(f"聊天请求出现错误: {e}")

    def changeApiKey(self, newApiKey):
        # 密钥直接更改不会生效,还要调用豆包api设置的初始化
        self.apiKey = newApiKey  # 更改api密钥
        self.initDouBao()  # 更改密钥后初始化豆包设置

    def languageDetermination(self, content):
        try:
            # 尝试打开并读取 translatorConfig.json 文件
            with open(r"translatorConfig\languageDetermination.json", 'r', encoding='utf-8') as f:
                # 使用 json.load 直接从文件对象中读取并解析 JSON 数据
                config = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # 处理文件不存在,或者格式错误的情况
            print("判断器配置文件不存在,或者内容格式异常")
            return 0

        try:
            # self.config["role_path"]代表的路径文件为角色的设定文本文件
            with open(config["role_path"], 'r', encoding='utf-8') as f:
                # 存储角色设定文本
                roleSetText = f.read()
        except FileNotFoundError:
            # 处理文件不存在,或者格式错误的情况
            print("判断器格式设定文本文件不存在")
            return 0
        # content为用户要发送的聊天内容
        languageDeterminationMessages = [{"role": "system", "content": roleSetText},
                                         {"role": "user", "content": "请判断:" + content + "属于什么语言"}]
        try:
            completion = self.configDouBao.chat.completions.create(
                model=self.modelId,
                messages=languageDeterminationMessages,
                # 是否流式响应
                stream=self.stream,
                max_tokens=self.max_tokens,
                stop=self.stop,
                frequency_penalty=self.frequency_penalty,
                presence_penalty=self.presence_penalty,
                temperature=self.temperature,
                top_p=self.top_p,
                logprobs=self.logprobs,
                top_logprobs=self.top_logprobs,
                logit_bias=self.logit_bias
            )
            # 将 得到的回答的JSON 字符串转换为 Python 字典
            self.languageDetermination_dict = json.loads(completion.choices[0].message.content)
        except Exception as e:
            print(f"聊天请求出现错误: {e}")

    def exit(self):
        # 豆包ai退出时进行数据保存工作
        self.config["role_name"] = self.roleName
        self.config["api_key"] = self.apiKey
        self.config["model"] = self.modelId
        self.config["role_path"] = "translatorConfig/translatorConfig.txt"
        self.config["set"]["stream"] = self.stream
        self.config["set"]["max_tokens"] = self.max_tokens
        self.config["set"]["stop"] = self.stop
        self.config["set"]["frequency_penalty"] = self.frequency_penalty
        self.config["set"]["presence_penalty"] = self.presence_penalty
        self.config["set"]["temperature"] = self.temperature
        self.config["set"]["top_p"] = self.top_p
        self.config["set"]["logprobs"] = self.logprobs
        self.config["set"]["top_logprobs"] = self.top_logprobs
        self.config["set"]["logit_bias"] = self.logit_bias

        # 将新数据保存到角色配置文件
        try:
            with open("translatorConfig/translator.json", 'w', encoding='utf-8') as f:
                # 使用 json.dump将self.config转换为json格式并写入文件,ensure_ascii=False：确保非 ASCII 字符（如中文）能正确写入文件
                json.dump(self.config, f, ensure_ascii=False, indent=4)
        except FileNotFoundError:
            # 处理文件不存在,或者格式错误的情况
            print("角色配置文件不存在,或者内容格式异常,文件保存失败")
            return


# ai = DouBaoAI()
# language = input("请输入要翻译为什么语言:\n")
# content1 = input("请输入要翻译的内容:\n")
# ai.languageDetermination(content1)
# ai.chat(language=language,content=content1)
# ai.exit()
# print(f"语言: {ai.languageDetermination_dict['language']}")
# print(f"翻译: {ai.translation_dict['translation']}")
# print(f"词性: {ai.translation_dict['part_of_speech']}")
# print(f"例句: {ai.translation_dict['example']}")
