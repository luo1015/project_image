import os
import sys
from PyQt5.QtWidgets import QApplication, QFrame, QVBoxLayout

from function.menu.appCustomize import AppCustomFrame
from function.aiTranslator.aiTranslator import MainWindow


class AiTranslator:
    def __init__(self):
        # 获取当前文件的绝对路径
        current_file_path = os.path.abspath(__file__)
        # 获取当前文件所在的目录
        current_directory = os.path.dirname(current_file_path)
        image_path = os.path.join(current_directory, "aiTranslator.png")
        self.customFrame = AppCustomFrame(icon_path=image_path,
                                          app_text="翻译")
        self.translationWin = MainWindow()
        self.customFrame.clicked.connect(self.show_aiTranslatorWin)
        self.isShow = False

    def show_aiTranslatorWin(self):
        if not self.isShow:
            self.translationWin.show()
            self.isShow = True
        else:
            self.translationWin.hide()
            self.isShow = False


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 创建带点击事件的Frame
    frame = Translation()

    test_window = QFrame()
    test_window.setLayout(QVBoxLayout())
    test_window.layout().addWidget(frame.customFrame)
    test_window.show()
    sys.exit(app.exec_())
