import sys

from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtWidgets import QApplication, QFrame, QVBoxLayout

from function.topMenu.topFunctionWin import TopCustomFrame
from function.pluginStore.pluginStore import WebviewProcessManager


class PluginStore(QObject):
    # 定义一个被点击信号，当任务完成时发送消息给主线程
    closeSignal = pyqtSignal(bool)

    def __init__(self):
        super().__init__()
        self.customFrame = TopCustomFrame(icon_path="static/images/menuIcon/pluginStore.png",
                                          function_name="插件商店")
        self.store = WebviewProcessManager()
        self.customFrame.clicked.connect(self.run)

    def run(self):
        self.store.start_webview()
        print("发送,关闭信号为True")
        self.closeSignal.emit(True)
        print("发送成功")


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 创建带点击事件的Frame
    frame = OpenMenu()

    test_window = QFrame()
    test_window.setLayout(QVBoxLayout())
    test_window.layout().addWidget(frame.customFrame)
    test_window.show()
    sys.exit(app.exec_())
