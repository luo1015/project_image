import os
import threading
import time

import webview
import multiprocessing
from function.pluginStore.workWithFiles import FileMonitorThread


class PluginStoreWindow:
    def __init__(self):
        # 获取当前文件的绝对路径
        current_file_path = os.path.abspath(__file__)
        # 获取当前文件所在的目录
        current_directory = os.path.dirname(current_file_path)
        # 得到function目录
        self.function_path = os.path.dirname(current_directory)
        # 得到下载压缩文件的路径
        self.zipFiles_path = os.path.join(self.function_path, 'zipFiles')

    def open_window(self):
        window = webview.create_window('插件商店', 'http://127.0.0.1:5000/', width=1000, height=600)
        # 设置自定义下载路径
        webview.settings['ALLOW_DOWNLOADS'] = True
        webview.settings['DOWNLOADS_PATH'] = self.zipFiles_path
        # 监听窗口关闭事件
        window.events.closed += self.on_closed
        # 监听窗口已显示事件
        window.events.shown += self.on_shown

        webview.start()

    def on_closed(self):
        print("窗口已关闭")
        # 这里需要确保 FileMonitorThread 类有 stop 方法
        # monitor_thread.stop()

    def on_before_show(self, monitor_thread):
        print("窗口即将显示")

    def on_shown(self):
        print("窗口已显示")
        # 这里可以添加你想要在窗口已显示时执行的代码


class WebviewProcessManager:
    def __init__(self):
        multiprocessing.freeze_support()
        self.store = PluginStoreWindow()
        self.webview_process = multiprocessing.Process(target=self.store.open_window)
        self.monitor_thread = None

        # 获取当前文件的绝对路径
        current_file_path = os.path.abspath(__file__)
        # 获取当前文件所在的目录
        current_directory = os.path.dirname(current_file_path)
        # 得到function目录
        self.function_path = os.path.dirname(current_directory)
        # 得到下载压缩文件的路径
        self.zipFiles_path = os.path.join(self.function_path, 'zipFiles')
        # 在新进程里创建文件监控线程
        self.monitor_thread2 = FileMonitorThread(self.zipFiles_path)

    def start_webview(self):
        self.webview_process = multiprocessing.Process(target=self.store.open_window)
        self.webview_process.start()
        self.start_monitor_thread()
        self.monitor_thread2.start()

    def wait_for_completion(self):
        self.webview_process.join()

    def start_monitor_thread(self):
        self.monitor_thread = threading.Thread(target=self.monitor_process)
        self.monitor_thread.start()

    def monitor_process(self):
        while True:
            if self.webview_process.is_alive():
                print("Webview 进程正在运行")
            else:
                print("Webview 进程未运行")
                self.monitor_thread2.stop()
                break
            time.sleep(1)  # 每秒检查一次

    def monitor_thread2_finished(self):
        while not self.monitor_thread2.fs:
            pass


if __name__ == "__main__":
    manager = WebviewProcessManager()
    manager.start_webview()
    manager.wait_for_completion()
