import os
import sys

from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtWidgets import QApplication, QFrame, QVBoxLayout

from function.menu.appCustomize import AppCustomFrame
from function.screenshot.getScreenshotPhoto import ScreenshotBegin


class OpenStore(QObject):
    # 定义一个被点击信号，当任务完成时发送消息给主线程
    closeSignal = pyqtSignal(bool)

    def __init__(self):
        super().__init__()
        # 获取当前文件的绝对路径
        current_file_path = os.path.abspath(__file__)
        # 获取当前文件所在的目录
        current_directory = os.path.dirname(current_file_path)
        image_path = os.path.join(current_directory, "pluginStore.png")
        self.customFrame = AppCustomFrame(icon_path=image_path,
                                          app_text="插件商店")
        self.translationWin = ScreenshotBegin()
        self.customFrame.clicked.connect(self.run)
        # 记录按钮是否处于展开状态
        self.isUnfolded = False

    def run(self):
        print("发送,关闭信号为True")
        self.closeSignal.emit(True)
        print("发送成功")
        print("插件市场暂为开放")


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 创建带点击事件的Frame
    frame = OpenMenu()

    test_window = QFrame()
    test_window.setLayout(QVBoxLayout())
    test_window.layout().addWidget(frame.customFrame)
    test_window.show()
    sys.exit(app.exec_())
