import json
import os
import shutil
import sys
import time
import zipfile

from PyQt5.QtCore import QThread, pyqtSignal
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


def change_case_at_index(s, index):
    # 改变字符串指定位置下标大小写
    if 0 <= index < len(s):
        new_char = s[index].swapcase()
        return s[:index] + new_char + s[index + 1:]
    return s


class ZipExtractor:
    # 类的初始化方法，接收两个参数：zip_file_path 和 extract_path
    def __init__(self):
        # 将传入的要解压的 ZIP 文件的路径赋值给类的实例属性 zip_file_path
        self.zip_file_path = None
        # 将传入的目标解压目录的路径赋值给类的实例属性 extract_path
        self.extract_path = None

    # 定义解压方法，用于将指定的 ZIP 文件解压到指定目录
    def extract(self, zip_file_path, extract_path):
        self.zip_file_path = zip_file_path
        self.extract_path = extract_path
        """
        解压指定路径的 ZIP 压缩文件到指定目录
        """
        try:
            # 检查目标解压目录是否存在，如果不存在则执行下面的操作
            if not os.path.exists(self.extract_path):
                # 使用 os.makedirs 方法创建目标解压目录，包括所有必要的中间目录
                os.makedirs(self.extract_path)
            # 使用 zipfile.ZipFile 以只读模式打开指定的 ZIP 文件
            with zipfile.ZipFile(self.zip_file_path, 'r') as zip_ref:
                print("开始解压")
                # 调用 extractall 方法将 ZIP 文件中的所有内容解压到指定的目标目录
                zip_ref.extractall(self.extract_path)
            # 若解压成功，打印成功信息，包含要解压的 ZIP 文件路径和目标解压目录路径
            print(f"成功解压 {self.zip_file_path} 到 {self.extract_path}")
        # 捕获在解压过程中可能出现的任何异常
        except Exception as e:
            # 若解压过程中出现异常，打印错误信息，包含要解压的 ZIP 文件路径和具体的错误内容
            print(f"解压 {self.zip_file_path} 时出错: {e}")


class MyHandler(FileSystemEventHandler):
    # 初始化方法，接收一个信号对象，用于在文件变化时发送消息
    def __init__(self, signal):
        self.signal = signal
        self.file_save_Fished = signal
        self.file_list = []

    # 当文件被修改时触发此方法
    def on_modified(self, event):
        # 发送文件修改的消息
        self.signal.emit(f"文件 {event.src_path} 已被修改。")
        print(self.file_list)

    # 当文件被创建时触发此方法
    def on_created(self, event):
        print("文件创建事件触发:", event.src_path)
        # 发送文件创建的消息
        self.signal.emit(f"文件 {event.src_path} 已被创建。")
        print(f"文件{event.src_path}已被添加")
        self.file_list.append(event.src_path)
        print(self.file_list)

    # 当文件被删除时触发此方法
    def on_deleted(self, event):
        print("文件删除事件触发:", event.src_path)
        # 发送文件删除的消息
        self.signal.emit(f"文件 {event.src_path} 已被删除。")
        if event.src_path in self.file_list:
            self.file_list.remove(event.src_path)
            print(self.file_list)


class FileMonitorThread(QThread):
    # 定义一个信号，用于发送文件变化的消息
    message_signal = pyqtSignal(str)
    threadFinished_signal = pyqtSignal()

    # 初始化方法，接收要监控的目录路径
    def __init__(self, path):
        super().__init__()
        self.event_handler = None
        self.path = path
        self.fileSavedList = None
        # 文件配置是否完成标志位
        self.fs = False
        # 添加一个标志位用于控制线程的运行
        self._running = True
        # 创建解压类
        self.ze = ZipExtractor()
        # 获取当前文件的绝对路径
        current_file_path = os.path.abspath(__file__)
        # 获取当前文件所在的目录
        current_directory = os.path.dirname(current_file_path)
        # 得到function目录
        self.function_path = os.path.dirname(current_directory)

    def run(self):
        print("文件监控开始运行")
        self.delete_directory_contents(self.path)
        self.event_handler = MyHandler(self.message_signal)
        observer = Observer()
        observer.schedule(self.event_handler, self.path, recursive=False)
        observer.start()
        try:
            while self._running:
                time.sleep(1)
            self.fileSavedList = self.event_handler.file_list
            # 运行解压函数
            self.zip_extractor()
        except Exception as e:
            print(f"线程运行出现异常: {e}")
            self.fileSavedList = self.event_handler.file_list
            # 运行解压函数
            self.zip_extractor()
        finally:
            observer.stop()
            observer.join()

    def stop(self):
        # 修改标志位以停止线程
        self._running = False

    def zip_extractor(self):
        print("开始解压1")
        if self.fileSavedList:
            # 若保存的文件列表不为空则进行解压
            for file_path in self.fileSavedList:
                self.ze.extract(zip_file_path=file_path, extract_path=self.function_path)
                print("解压完成")
                self.change_top_config(file_path)
                self.change_config(file_path)
                self.delete_file(file_path)
                self.fs = True

        # 自定义方法，用于删除指定文件

    def delete_file(self, file_path):
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                print(f"成功删除文件: {file_path}")
                if file_path in self.fileSavedList:
                    self.fileSavedList.remove(file_path)
            else:
                print(f"文件 {file_path} 不存在，无法删除。")
        except PermissionError:
            print(f"没有权限删除文件: {file_path}")
        except Exception as e:
            print(f"删除文件 {file_path} 时出现错误: {e}")

    def change_top_config(self, file_path):
        try:
            # 获取文件名,去掉.zip
            dir_name = os.path.basename(file_path)[:-4]
            # 将下标0改为大写
            file_name = f'top{change_case_at_index(dir_name, 0)}Win'
            # json文件的key
            key = f'function.{dir_name}.{file_name}'
            # json文件的value
            value = change_case_at_index(dir_name, 0)
            # 拼接顶部模块列表路径
            topModuleList_path = os.path.join(self.function_path, 'topMenu', 'topModuleList.json')

            try:
                with open(topModuleList_path, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    # 将key和value加入字典
                    data["SlideToolbarWin"][key] = value
                with open(topModuleList_path, 'w', encoding='utf-8') as file:
                    # 1.将data转换为json形象并写入
                    json.dump(data, file, ensure_ascii=False, indent=4)

            except FileNotFoundError:
                print(f"错误: 文件 {topModuleList_path} 未找到。")
            except json.JSONDecodeError:
                print(f"错误: 无法解析 {topModuleList_path} 为有效的 JSON 数据。")
            except Exception as e:
                print(f"发生未知错误: {e}")

        except PermissionError:
            print("更新topModuleList失败")
        except Exception as e:
            print("更新topModuleList失败")

    def change_config(self, file_path):
        try:
            # 获取目录,去掉.zip
            dir_name = os.path.basename(file_path)[:-4]
            # 将下标0改为大写
            file_name = f'{dir_name}Win'
            # json文件的key
            key = f'function.{dir_name}.{file_name}'
            # json文件的value
            value = change_case_at_index(dir_name, 0)
            # 拼接顶部模块列表路径
            moduleList_path = os.path.join(self.function_path, 'menu', 'moduleList.json')

            try:
                with open(moduleList_path, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    # 将key和value加入字典
                    data[key] = value
                with open(moduleList_path, 'w', encoding='utf-8') as file:
                    # 1.将data转换为json形象并写入
                    json.dump(data, file, ensure_ascii=False, indent=4)

            except FileNotFoundError:
                print(f"错误: 文件 {moduleList_path} 未找到。")
            except json.JSONDecodeError:
                print(f"错误: 无法解析 {moduleList_path} 为有效的 JSON 数据。")
            except Exception as e:
                print(f"发生未知错误: {e}")

        except PermissionError:
            print("更新moduleList_path失败")
        except Exception as e:
            print("更新moduleList_path失败")

    def delete_directory_contents(self, directory):
        # 检查目录是否存在
        if os.path.exists(directory):
            # 遍历目录中的所有文件和文件夹
            for root, dirs, files in os.walk(directory):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        # 删除文件
                        os.remove(file_path)
                        print(f"已删除文件: {file_path}")
                    except Exception as e:
                        print(f"删除文件 {file_path} 时出错: {e}")
                for dir in dirs:
                    dir_path = os.path.join(root, dir)
                    try:
                        # 删除文件夹及其内容
                        shutil.rmtree(dir_path)
                        print(f"已删除文件夹: {dir_path}")
                    except Exception as e:
                        print(f"删除文件夹 {dir_path} 时出错: {e}")
        else:
            print(f"指定的目录 {directory} 不存在。")


if __name__ == "__main__":
    # 获取当前文件的绝对路径
    current_file_path = os.path.abspath(__file__)
    # 获取当前文件所在的目录
    current_directory = os.path.dirname(current_file_path)
    # 得到function目录
    function_path = os.path.dirname(current_directory)
    print("监控的目录路径:", function_path)
    # 请将这里替换为你要监控的目录
    path = function_path
    # 创建文件监控线程对象，传入要监控的目录路径
    monitor_thread = FileMonitorThread(path)
    # 将线程的消息信号连接到一个匿名函数，用于打印消息
    monitor_thread.message_signal.connect(lambda msg: print(msg))
    # 启动线程
    monitor_thread.start()

    try:
        # 进入一个无限循环，让主线程保持运行
        while True:
            # 主线程休眠1秒
            time.sleep(1)
    except KeyboardInterrupt:
        # 当用户按下 Ctrl+C 时，请求线程退出
        monitor_thread.quit()
        # 等待线程结束
        monitor_thread.wait()
