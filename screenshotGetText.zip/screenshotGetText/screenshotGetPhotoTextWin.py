import os
import sys
from PyQt5.QtWidgets import QApplication, QFrame, QVBoxLayout
from function.menu.appCustomize import AppCustomFrame
from function.screenshotGetText.screenshotGetPhotoText import ScreenshotToText


class ScreenshotGetText:
    def __init__(self):
        # 获取当前文件的绝对路径
        current_file_path = os.path.abspath(__file__)
        # 获取当前文件所在的目录
        current_directory = os.path.dirname(current_file_path)
        image_path = os.path.join(current_directory, "ocr.png")
        self.customFrame = AppCustomFrame(icon_path=image_path,
                                          app_text="截图提取文本")
        self.screenshot = ScreenshotToText()
        self.customFrame.clicked.connect(self.runScreenshot)

    def runScreenshot(self):
        self.screenshot.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 创建带点击事件的Frame
    frame = ScreenshotGetText()

    test_window = QFrame()
    test_window.setLayout(QVBoxLayout())
    test_window.layout().addWidget(frame.CustomFrame)
    test_window.show()
    sys.exit(app.exec_())
