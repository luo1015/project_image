import sys
from PIL import ImageGrab, Image
from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen, QPainterPath, QColor
from PyQt5.QtWidgets import QWidget, QApplication
from PyQt5.QtCore import QRect, QPoint, Qt, pyqtSignal, QThread, QTimer
from rapidocr_onnxruntime import RapidOCR
from function.screenshotGetText.TextWin_rc import Ui_Form

"""
这是一个截图后提取文本的模块,Screenshot类先进行全屏截图，然后使用无边框的QWidget窗口设置背景为全屏截图置顶显示提供截图控件，再重写鼠标的点击事件和绘画事件
来实现。图片提取文本的方法。
"""


class PhotoToTextThread(QThread):
    # 定义一个信号，当图片转换为文本成功后发送此信号
    toTextFinished = pyqtSignal(str)  # str为提取完成后的不包括其他信息的文本内容

    def __init__(self, img: Image):
        super().__init__()
        print("PhotoToTextThread1")
        self.img = img
        print("PhotoToTextThread2")

    def run(self) -> None:
        print("PhotoToTextThreadRun1")
        """
                基于RapidOCR的图像提取文本技术
                :return:
                """
        engine = RapidOCR()
        print("PhotoToTextThreadRun2")
        result, elapse = engine(self.img)
        if not result:
            self.toTextFinished.emit('未识别到内容')
            return
        contentText = ''
        for text in result:
            contentText += text[1] + '\n'
        print("PhotoToTextThreadRun3")
        print(contentText)
        self.toTextFinished.emit(contentText)
        print("PhotoToTextThreadRun4")


class TextWin(QWidget):
    def __init__(self,):
        print("TextWin__init__1")
        super().__init__()
        # self.move(moveAddress)
        self.offset = None
        self.dragging = None
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.setAttribute(Qt.WA_TranslucentBackground)  # 启用透明背景
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)  # 隐藏标题栏
        self.ui.pushButton_4.clicked.connect(self.hide)
        print("TextWin__init__2")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            if event.x() < self.geometry().width() and event.y() < self.geometry().height():
                # 判断鼠标按下的位置是否在被允许拖动窗口的范围内
                self.dragging = True
            # 记录鼠标按下时相对于窗口左上角的偏移量
            self.offset = event.pos()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.LeftButton and self.dragging:
            # 计算窗口新的位置
            new_pos = self.pos() + event.pos() - self.offset
            self.move(new_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragging = False


class ScreenshotToText(QWidget):

    def __init__(self):
        super().__init__()
        self.textWinContent = None  # 存储图片提取文本窗口要输入的文本内容,主要是为了给changeTextWin2方法使用
        self.pixmap = QPixmap()  # 存储原始截图
        self.getWindowPhoto()  # 初始化截图
        self.textWin = TextWin()  # 截图完成后的文本窗口
        self.textWin.hide()
        # self.textWin = None  # 截图完成后的文本窗口

        self.img = None  # 存储截图后的Image类型图片

        # 坐标跟踪
        self.start_pos = QPoint()
        self.current_pos = QPoint()
        self.painting = False  # 绘制状态标志

        # 用于存储图片转文本线程
        self.photoToTextThread = None

        # 使用定时器模拟键盘输入改变多行文本框
        # 创建定时器和提取文本字符串的下标,用于图片提取文本窗口的打印功能
        self.timer = QTimer(self)
        # 设置定时器单次触发
        self.timer.setSingleShot(True)
        # 连接定时器的 timeout 信号到延迟任务函数
        self.timer.timeout.connect(self.changeTextWin2)
        self.chatIndex = 0

        self.initUI()

    def initUI(self):
        """界面初始化"""
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(self.pixmap.size())

    def getWindowPhoto(self):
        """获取屏幕截图"""
        photo = ImageGrab.grab()
        # 转换为QImage
        qimage = QImage(
            photo.tobytes("raw", "RGB"),
            photo.width,
            photo.height,
            QImage.Format_RGB888
        )
        self.pixmap = QPixmap.fromImage(qimage)

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            self.start_pos = event.pos()
            self.current_pos = event.pos()
            self.painting = True
            event.accept()

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.painting:
            self.current_pos = event.pos()
            self.update()  # 触发实时重绘
            event.accept()

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if event.button() == Qt.LeftButton:
            self.painting = False
            address = self.get_rect()
            bbox = (
                address.x() + 2, address.y() + 2, address.x() + address.width() - 2, address.y() + address.height() - 2)
            # 将得到的截图保存在变量中
            self.img = ImageGrab.grab(bbox)

            # 在关闭截图窗口前创建提取文字窗口类,这样可以更准确显示到鼠标释放的位置
            # self.textWin = TextWin(event.pos())
            # 设置self.textWin 的复制按钮控件槽函数
            self.textWin.ui.pushButton.clicked.connect(self.textWin.ui.plainTextEdit.copy)
            self.close()
            # 关闭截图窗口后打开提取文字窗口
            self.textWin.show()
            self.photoToTextThread = PhotoToTextThread(self.img)
            self.photoToTextThread.toTextFinished.connect(self.changeTextWin)
            self.photoToTextThread.start()
            event.accept()

    def get_rect(self):
        """计算标准化矩形"""
        return QRect(
            min(self.start_pos.x(), self.current_pos.x()),
            min(self.start_pos.y(), self.current_pos.y()),
            abs(self.current_pos.x() - self.start_pos.x()),
            abs(self.current_pos.y() - self.start_pos.y())
        )

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)

        if not hasattr(self, '_cached_mask'):
            # 创建与窗口同尺寸的半透明遮罩
            self._cached_mask = QPixmap(self.size())
            self._cached_mask.fill(QColor(50, 50, 50, 150))

        painter.drawPixmap(0, 0, self._cached_mask)

        if self.painting:
            painter.setCompositionMode(QPainter.CompositionMode_Clear)
            painter.fillRect(self.get_rect(), Qt.transparent)

            # 恢复合成模式后绘制边框
            painter.setCompositionMode(QPainter.CompositionMode_SourceOver)
            painter.setPen(QPen(Qt.yellow, 2, Qt.DashLine))
            painter.drawRect(self.get_rect())

    def changeTextWin(self, content):
        # 清除当前文本框内容
        self.textWin.ui.plainTextEdit.clear()
        self.textWinContent = content
        # 设置延迟时间为 100 毫秒（即 0.1 秒）
        self.timer.start(50)

    def changeTextWin2(self):
        # changeChatWin1函数运行开启计时器调用此方法
        if self.chatIndex <= len(self.textWinContent) - 1:
            # 满足条件代表信息还未打印完,当信息打印完成开启的下一个线程会进入else将下标初始化为0并不在开启线程
            self.textWin.ui.plainTextEdit.insertPlainText(self.textWinContent[self.chatIndex])
            print("更改成功1")
            print(self.textWinContent[self.chatIndex])
            self.chatIndex += 1
            # 再次开启此线程
            self.timer.start(50)
        else:
            self.chatIndex = 0


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ScreenshotToText()
    window.show()
    sys.exit(app.exec_())
