import io
import os
import sys
from datetime import datetime

import win32clipboard
from PIL.Image import Image
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QMenu, QAction, QGraphicsDropShadowEffect
from PyQt5.QtCore import Qt, QPoint
from PyQt5.QtGui import QPixmap, QWheelEvent, QColor, QImage


class PhotoLevitation(QWidget):
    def __init__(self, photo: Image):
        super().__init__()
        self.photo = photo
        # 转换为QImage
        image = QImage(
            self.photo.tobytes("raw", "RGBA"),
            self.photo.width,
            self.photo.height,
            self.photo.width * 4,  # 每行字节数 = 宽度 * 4 (RGBA)
            QImage.Format_RGBA8888  # 正确匹配4通道格式
        )
        self.pixmap = QPixmap.fromImage(image)  # 保存原始图片
        self.photoScaledData = 1.0  # 记录当前图片缩放比例
        self.initUI()

    def initUI(self):
        # 设置窗口属性
        self.setWindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # 添加图片标签
        self.label = QLabel(self)
        self.updatePixmap()

        # 初始化拖动变量
        self.dragging = False
        # 初始化偏移量变量
        self.offset = QPoint()

        # 创建右键菜单
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.showContextMenu)

        # 设置阴影效果
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)  # 设置模糊半径
        shadow.setXOffset(0)  # 设置水平偏移
        shadow.setYOffset(0)  # 设置垂直偏移
        shadow.setColor(QColor(0, 0, 0, 160))  # 设置阴影颜色
        # 将阴影效果设置给标签
        self.label.setGraphicsEffect(shadow)

    def showContextMenu(self, pos):
        # 右键菜单
        menu = QMenu(self)
        # 创建三个选项,复制、保存到桌面、关闭
        copy_action = QAction('复制', self)
        save_action = QAction('保存到桌面', self)
        exit_action = QAction('关闭', self)
        # 加入选项到右键菜单
        menu.addAction(copy_action)
        menu.addAction(save_action)
        menu.addAction(exit_action)

        # 信号链接
        copy_action.triggered.connect(self.save_toClipboard)
        save_action.triggered.connect(self.save_desktop)
        exit_action.triggered.connect(self.close)

        menu.exec_(self.mapToGlobal(pos))

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragging = True
            self.offset = event.pos()

    def mouseMoveEvent(self, event):
        if self.dragging:
            self.move(self.mapToGlobal(event.pos() - self.offset))

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragging = False

    def wheelEvent(self, event: QWheelEvent):
        # 记录旧的中心点坐标
        oldCenter = self.geometry().center()
        # 获取鼠标滚轮在垂直方向的角度变化值
        wheelY = event.angleDelta().y()
        if wheelY > 0:
            self.photoScaledData += 0.1
        else:
            self.photoScaledData -= 0.1
        # 限制图片的缩放范围为0.1~5
        self.photoScaledData = max(0.1, min(self.photoScaledData, 5.0))
        # 更新图片大小
        self.updatePixmap()
        # 保持窗口中心点不变
        new_geo = self.geometry()
        new_geo.moveCenter(oldCenter)
        self.setGeometry(new_geo)

    def updatePixmap(self):
        # 对图像按图片缩放数据进行缩放操作
        scaledPixmap = self.pixmap.scaled(int(self.pixmap.width() * self.photoScaledData),
                                          int(self.pixmap.height() * self.photoScaledData),
                                          aspectRatioMode=Qt.KeepAspectRatio,
                                          transformMode=Qt.SmoothTransformation)
        # 将缩放后的图片在label上更新
        self.label.setPixmap(scaledPixmap)
        self.label.resize(scaledPixmap.size())
        # 更新缩放后的窗口大小,长宽个加30为阴影效果
        self.resize(self.label.width() + 30, self.label.height() + 30)

    def save_desktop(self):
        # 使用os.path.join把os.path.expanduser("~")获取到的home路径与Desktop路径拼接成个人桌面路径
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        # 获取当前时间
        now = datetime.now()
        # 通过当前时间拼接成要保存到桌面的文件名
        now_name = str(now.date()) + ' ' + str(now.hour) + str(now.minute) + str(now.second) + '.png'
        # 拼接成完整的路径
        save_file_name = os.path.join(desktop_path, now_name)
        self.photo.save(save_file_name)

    def save_toClipboard(self):
        if self.photo:
            image = self.photo
            output = io.BytesIO()
            image.save(output, format='BMP')
            image_data = output.getvalue()
            output.close()
            # 打开win原生剪切板
            win32clipboard.OpenClipboard()
            # 情况剪切板内容
            win32clipboard.EmptyClipboard()
            # 将图片格式为BMP的数据保存进剪切板
            # 因为剪切板数据格式设置为DIB（设备无关位图）格式,它与BMP格式相似，
            # 但文件头（特别是位图信息头）有所不同,因此要从第15个字节开始保存
            image_data = image_data[14:]
            # 将数据保存入剪切板
            win32clipboard.SetClipboardData(win32clipboard.CF_DIB, image_data)
            # 关闭剪切板
            win32clipboard.CloseClipboard()


if __name__ == "__main__":
    from PIL import Image

    img = Image.open("测试图片.png")
    app = QApplication(sys.argv)
    window = PhotoLevitation(img)
    window.show()
    sys.exit(app.exec_())
