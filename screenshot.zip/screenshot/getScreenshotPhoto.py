import sys
from PIL import ImageGrab
from PIL.Image import Image
from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen, QPainterPath, QColor
from PyQt5.QtWidgets import QWidget, QApplication
from PyQt5.QtCore import QRect, QPoint, Qt, pyqtSignal
from function.screenshot.photoLevitation import PhotoLevitation

"""
这是一个截图的模块,Screenshot类先进行全屏截图，然后使用无边框的QWidget窗口设置背景为全屏截图置顶显示提供截图控件，再重写鼠标的点击事件和绘画事件
来实现。
"""


class ScreenshotBegin(QWidget):
    # 创建截图完成的信号
    screenshotFinished = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.pixmap = QPixmap()  # 存储原始截图
        self.getWindowPhoto()  # 初始化截图
        self.photoLevitationList = []  # 截图悬浮框列表

        self.img = Image()  # 存储截图后的Image类型图片

        # 坐标跟踪
        self.start_pos = QPoint()
        self.current_pos = QPoint()
        self.painting = False  # 绘制状态标志

        # 连接槽函数
        self.screenshotFinished.connect(self.screenshotLevitation)

        self.initUI()

    def initUI(self):
        """界面初始化"""
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(self.pixmap.size())

    def getWindowPhoto(self):
        """获取屏幕截图"""
        photo = ImageGrab.grab()
        # 转换为QImage
        image = QImage(
            photo.tobytes("raw", "RGBA"),
            photo.width,
            photo.height,
            photo.width * 4,  # 每行字节数 = 宽度 * 4 (RGBA)
            QImage.Format_RGBA8888  # 正确匹配4通道格式
        )
        self.pixmap = QPixmap.fromImage(image)

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            self.start_pos = event.pos()
            self.current_pos = event.pos()
            self.painting = True
            event.accept()

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.painting:
            self.current_pos = event.pos()
            self.update()  # 触发实时重绘
            event.accept()

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if event.button() == Qt.LeftButton:
            self.painting = False
            address = self.get_rect()
            bbox = (
                address.x() + 2, address.y() + 2, address.x() + address.width() - 2, address.y() + address.height() - 2)
            # 将得到的截图保存在变量中
            self.img = ImageGrab.grab(bbox)
            self.close()
            # 先关闭当前截图窗口再发送截图完成的信号
            self.screenshotFinished.emit()
            event.accept()

    def get_rect(self):
        """计算标准化矩形"""
        return QRect(
            min(self.start_pos.x(), self.current_pos.x()),
            min(self.start_pos.y(), self.current_pos.y()),
            abs(self.current_pos.x() - self.start_pos.x()),
            abs(self.current_pos.y() - self.start_pos.y())
        )

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)

        if not hasattr(self, '_cached_mask'):
            # 创建与窗口同尺寸的半透明遮罩
            self._cached_mask = QPixmap(self.size())
            self._cached_mask.fill(QColor(50, 50, 50, 150))

        painter.drawPixmap(0, 0, self._cached_mask)

        if self.painting:
            painter.setCompositionMode(QPainter.CompositionMode_Clear)
            painter.fillRect(self.get_rect(), Qt.transparent)

            # 恢复合成模式后绘制边框
            painter.setCompositionMode(QPainter.CompositionMode_SourceOver)
            painter.setPen(QPen(Qt.yellow, 2, Qt.DashLine))
            painter.drawRect(self.get_rect())

    def screenshotLevitation(self):
        # 图片悬浮方法
        pl = PhotoLevitation(photo=self.img)
        pl.move(self.start_pos)
        pl.show()
        self.photoLevitationList.append(pl)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ScreenshotBegin()
    window.show()
    sys.exit(app.exec_())
